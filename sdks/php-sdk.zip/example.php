<?php
require_once 'PaytmGateway.php';

// CONFIG
$apiKey = 'YOUR_API_KEY'; // Get from Admin Panel
$baseUrl = 'https://pay.docsuvidha.com'; // Your Gateway URL

$pg = new PaytmGateway($apiKey, $baseUrl);

// Example: Create Order
echo "<h2>Creating Order...</h2>";
$response = $pg->createOrder([
    'order_id' => 'SDK_' . rand(1000, 9999),
    'amount' => 1.00,
    'customer_id' => 'Tester',
    'redirect_url' => 'https://google.com'
]);

echo "<pre>";
print_r($response);
echo "</pre>";

if ($response['status'] ?? false) {
    echo "<a href='" . $response['result']['payment_url'] . "' target='_blank'>Pay Now</a>";
}
?>