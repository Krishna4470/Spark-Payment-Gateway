# Paytm Gateway PHP SDK

A simple PHP wrapper for integrating the Paytm Payment Gateway.

## Installation

1. Copy the `PaytmGateway.php` file to your project.
2. Require it in your script.

## Usage

```php
require_once 'PaytmGateway.php';

// Initialize
$gateway = new PaytmGateway('YOUR_API_KEY', 'https://your-gateway-url.com');

// 1. Create Order
$order = $gateway->createOrder([
    'order_id' => 'ORD_' . time(),
    'amount' => 100,
    'customer_id' => 'CUST_001',
    'redirect_url' => 'https://yoursite.com/callback'
]);

if ($order['status']) {
    // Redirect user to payment page
    header("Location: " . $order['result']['payment_url']);
} else {
    echo "Error: " . $order['message'];
}

// 2. Check Status
$status = $gateway->checkStatus('ORD_12345');
print_r($status);
```
