<?php

class PaytmGateway {

    private $apiKey;
    private $baseUrl;

    /**
     * @param string $apiKey Your API Key from the Dashboard
     * @param string $baseUrl The Gateway URL (e.g. https://your-gateway.com)
     */
    public function __construct($apiKey, $baseUrl) {
        $this->apiKey = $apiKey;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * Create a new order
     * 
     * @param array $data ['order_id', 'amount', 'customer_id', 'redirect_url']
     * @return array Response with payment_url
     */
    public function createOrder($data) {
        $data['user_token'] = $this->apiKey;
        return $this->sendRequest('/api/create_order.php', $data);
    }

    /**
     * Check Order Status
     * 
     * @param string $orderId
     * @return array Status details
     */
    public function checkStatus($orderId) {
        $data = [
            'user_token' => $this->apiKey,
            'order_id' => $orderId
        ];
        return $this->sendRequest('/api/check_order_status.php', $data);
    }

    private function sendRequest($endpoint, $postData) {
        $ch = curl_init($this->baseUrl . $endpoint);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
        curl_setopt($ch, CURLOPT_USERAGENT, 'PaytmGateway-PHP-SDK/1.0');
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            return ['status' => false, 'message' => 'CURL Error: ' . curl_error($ch)];
        }
        
        curl_close($ch);
        return json_decode($response, true);
    }
}
?>
