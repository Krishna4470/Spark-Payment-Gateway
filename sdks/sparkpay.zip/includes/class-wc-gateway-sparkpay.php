<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_SparkPay extends WC_Payment_Gateway {

    public function __construct() {

        $this->id = 'sparkpay';
        $this->method_title = 'SparkPay';
        $this->method_description = 'SparkPay UPI Payment Gateway';
        $this->has_fields = false;
        $this->supports = ['products'];

        $this->init_form_fields();
        $this->init_settings();

        // ✅ Settings values
        $this->enabled   = $this->get_option('enabled');
        $this->title     = $this->get_option('title');
        $this->api_key   = $this->get_option('api_key');
        $this->base_url  = rtrim($this->get_option('base_url'), '/');

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );

        add_action('woocommerce_api_sparkpay_return', [$this, 'handle_return']);
    }

    /* ======================
       ADMIN SETTINGS
    ====================== */
    public function init_form_fields() {

        $this->form_fields = [

            'enabled' => [
                'title'   => 'Enable/Disable',
                'type'    => 'checkbox',
                'label'   => 'Enable SparkPay',
                'default' => 'yes'
            ],

            'title' => [
                'title'   => 'Title',
                'type'    => 'text',
                'default' => 'UPI (SparkPay)'
            ],

            'api_key' => [
                'title'       => 'API Key',
                'type'        => 'text',
                'description' => 'Enter your SparkPay API Key',
                'desc_tip'    => true
            ],

            // ✅ NEW BASE URL OPTION
            'base_url' => [
                'title'       => 'Base URL',
                'type'        => 'text',
                'description' => 'Example: https://example.com',
                'default'     => 'https://sparkpay.shorteasily.com',
                'desc_tip'    => true
            ],
        ];
    }

    /* ======================
       FORCE AVAILABILITY
    ====================== */
    public function is_available() {

        if ($this->enabled !== 'yes') {
            return false;
        }

        if (empty($this->api_key) || empty($this->base_url)) {
            return false;
        }

        return true;
    }

    /* ======================
       PROCESS PAYMENT
    ====================== */
    public function process_payment($order_id) {

        $order = wc_get_order($order_id);

        if (!$order) {
            wc_add_notice('Invalid order', 'error');
            return ['result' => 'failure'];
        }

        $return_url = add_query_arg(
            'order_id',
            'WC_' . $order->get_id(),
            add_query_arg('wc-api', 'sparkpay_return', home_url('/'))
        );

        $payload = [
            'user_token'    => $this->api_key,
            'amount'        => number_format($order->get_total(), 2, '.', ''),
            'order_id'      => 'WC_' . $order->get_id(),
            'redirect_url'  => $return_url,
            'customer_name' => $order->get_billing_first_name()
        ];

        $response = wp_remote_post(
            $this->base_url . '/api/create_order.php',
            [
                'body'    => $payload,
                'timeout' => 30
            ]
        );

        if (is_wp_error($response)) {
            wc_add_notice('Gateway connection failed', 'error');
            return ['result' => 'failure'];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!isset($body['status']) || $body['status'] !== true) {
            wc_add_notice($body['message'] ?? 'Payment gateway error', 'error');
            return ['result' => 'failure'];
        }

        $order->update_status('pending', 'Awaiting SparkPay payment');
        WC()->cart->empty_cart();

        return [
            'result'   => 'success',
            'redirect' => $body['result']['payment_url']
        ];
    }

    /* ======================
       RETURN & VERIFY PAYMENT
    ====================== */
    public function handle_return() {

        if (!isset($_GET['order_id'])) {
            wp_die('Order ID missing');
        }

        $order_id = str_replace('WC_', '', sanitize_text_field($_GET['order_id']));
        $order    = wc_get_order($order_id);

        if (!$order) {
            wp_die('Invalid order');
        }

        $response = wp_remote_post(
            $this->base_url . '/api/check_order_status.php',
            [
                'body' => [
                    'user_token' => $this->api_key,
                    'order_id'   => 'WC_' . $order_id
                ],
                'timeout' => 30
            ]
        );

        if (is_wp_error($response)) {
            wp_die('Verification failed');
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (
            isset($body['status']) &&
            $body['status'] === true &&
            ($body['result']['txnStatus'] ?? '') === 'SUCCESS'
        ) {
            $order->payment_complete($body['result']['utr'] ?? '');
            $order->add_order_note('SparkPay UPI payment successful');
            wp_redirect($this->get_return_url($order));
            exit;
        }

        $order->update_status('failed', 'SparkPay payment failed');
        wp_redirect(wc_get_checkout_url());
        exit;
    }
}

// ================================
// SparkPay – UPI Logo (Fixed Size)
// ================================
add_filter('woocommerce_gateway_icon', 'sparkpay_gateway_icon', 10, 2);

function sparkpay_gateway_icon($icon, $gateway_id) {

    if ($gateway_id !== 'sparkpay') {
        return $icon;
    }

    $icon_url = plugin_dir_url(dirname(__FILE__)) . 'assets/allupi.png';

    return '<img src="' . esc_url($icon_url) . '" 
        alt="UPI" 
        style="height:24px;width:auto;vertical-align:middle;" />';
}

