<?php
/**
 * Plugin Name: SparkPay WooCommerce Gateway
 * Plugin URI: https://digispark-krishna.blogspot.com/
 * Description: SparkPay UPI Payment Gateway for WooCommerce
 * Version: 1.0
 * Author: Krishna
 * Author URI: https://digispark-krishna.blogspot.com/
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'sparkpay_wc_init', 11);

function sparkpay_wc_init() {

    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-gateway-sparkpay.php';

    add_filter('woocommerce_payment_gateways', function ($methods) {
        $methods[] = 'WC_Gateway_SparkPay';
        return $methods;
    });
}
